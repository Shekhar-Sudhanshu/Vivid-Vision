import cv2
import pyautogui
import HandDetectionModule as hdm
import numpy as np

capture = cv2.VideoCapture(0)

scW, scH = pyautogui.size()
detector = hdm.HandDetector(maxHands=1, detectionCon=0.8)
camW = 640
camH = 480

frame = 100

smooth = 2
plocX, plocY = 0, 0
clocX, clocY = 0, 0

while True:
    _, img = capture.read()

    # Detecting Hands
    img = detector.detectHands(img)

    # Getting Landmarks
    lmList = detector.findLandmarks(img)

    if(len(lmList) != 0):
        # Getting the tip of index finger and middle finger
        x1, y1 = lmList[8][1], lmList[8][2]

        # Detecting Fingers that are up
        fingers = detector.fingersUp()

        #Rectangle
        cv2.rectangle(img, (frame, frame), (camW-frame, camH-frame), (255, 0, 255), 2)

        # Index Finger
        if(fingers[0] == 0 and fingers[1] == 1 and fingers[2] == 0 and fingers[3] == 0 and fingers[4] == 0):
            x = np.interp(x1, (frame, camW-frame), (0, scW))
            y = np.interp(y1, (frame, camH-frame), (0, scH))

            clocX = plocX + (x - plocX) / smooth
            clocY = plocY + (y - plocY) / smooth

            pyautogui.moveTo(scW-clocX, clocY)
            plocX, plocY = clocX, clocY

        # Click
        if(fingers[0] == 1 and fingers[1] == 1 and fingers[2] == 0 and fingers[3] == 0 and fingers[4] == 0):
            pyautogui.click()

        # Down Scroll
        if(fingers[0] == 0 and fingers[1] == 1 and fingers[2] == 1 and fingers[3] == 1 and fingers[4] == 0):
            pyautogui.scroll(-100)

        # Up Scroll
        if(fingers[0] == 0 and fingers[1] == 1 and fingers[2] == 1 and fingers[3] == 1 and fingers[4] == 1):
            pyautogui.scroll(100)

        # All tabs
        if(fingers[0] == 1 and fingers[1] == 1 and fingers[2] == 1 and fingers[3] == 1 and fingers[4] == 1):
            pyautogui.hotkey('win', 'tab')

    cv2.imshow("Live Camera", img)
    cv2.waitKey(1)