import mediapipe as mp
import cv2

class HandDetector():
    def __init__(self, mode=False, maxHands = 2, modelComplexity = 1, detectionCon = 0.5, trackingCon = 0.5):
        self.mode = mode
        self.maxHands = maxHands
        self.modelComplexity = modelComplexity
        self.detectionCon = detectionCon
        self.trackingCon = trackingCon

        self.mpHands = mp.solutions.hands
        self.hands = self.mpHands.Hands(self.mode, self.maxHands, self.modelComplexity, 
                                        self.detectionCon, self.trackingCon)
        self.mpDraw = mp.solutions.drawing_utils
        self.tips = [4, 8, 12, 16, 20]
    
    def detectHands(self, img, draw=True):
        imgRGB = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
        self.results = self.hands.process(imgRGB)

        if self.results.multi_hand_landmarks:
            for handLms in self.results.multi_hand_landmarks:
                if draw:
                    self.mpDraw.draw_landmarks(img, handLms, self.mpHands.HAND_CONNECTIONS)

        return img
    
    def findLandmarks(self, img, handNo=0, draw=True):
        self.landMarks = []

        if self.results.multi_hand_landmarks:
            curHand = self.results.multi_hand_landmarks[handNo]

            for id, lms in enumerate(curHand.landmark):
                h, w, c = img.shape
                cx, cy = int(lms.x * w), int(lms.y * h)

                self.landMarks.append([id, cx, cy])

                if draw:
                    cv2.circle(img, (cx, cy), 5, (255, 255, 255), cv2.FILLED)

        return self.landMarks
    
    def fingersUp(self):
        fingers = []

        if(self.landMarks[self.tips[0]][1] > self.landMarks[self.tips[0] - 1][1]):
            fingers.append(1)
        else:
            fingers.append(0)


        for id in range(1, 5):
            if(self.landMarks[self.tips[id]][2] < self.landMarks[self.tips[id] - 2][2]):
                fingers.append(1)
            else:
                fingers.append(0)


        return fingers